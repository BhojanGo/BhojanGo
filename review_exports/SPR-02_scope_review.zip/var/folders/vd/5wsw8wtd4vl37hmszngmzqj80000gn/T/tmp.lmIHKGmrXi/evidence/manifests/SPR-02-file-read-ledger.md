# SPR-02 File Read Ledger

**Date:** 2026-06-15
**Session:** SPR-02 — Browsable Prototype

---

## Required plan/evidence files (all read end-to-end)

| File Path | Exists | Read End-to-End | Changed | In Closure Zip | Reason | Scope IDs |
|---|---|---|---|---|---|---|
| `implementation_plan/SP20-Master-Implementation-Sprint-Plan.md` | yes | yes | no | no | Reference only | — |
| `implementation_plan/IP.PR.02 - Browsable Prototype.md` | yes | yes | no | no | Reference only | — |
| `tests/results/evidence/summaries/current_handoff.md` | yes | yes | no | yes | Handoff context | — |
| `tests/results/evidence/manifests/SPR-01-evidence.md` | yes | yes | no | no | Prior closure | — |
| `tests/results/evidence/manifests/SPR-01-file-read-ledger.md` | yes | yes | no | no | Prior closure | — |
| `BLOCKERS.md` | yes | yes | no | no | Blocker reference | — |

---

## Restaurant service files

| File Path | Exists | Read End-to-End | Changed | In Closure Zip | Reason | Scope IDs |
|---|---|---|---|---|---|---|
| `services/restaurant-svc/app/api/v1/restaurants.py` | yes | yes | **yes** | yes | Added OpenSearch fallback to search endpoint | IP.PR.02.001 |
| `services/restaurant-svc/app/repositories/restaurant.py` | yes | yes | no | yes | Unchanged reference | — |
| `services/restaurant-svc/app/models/menu.py` | yes | yes | no | yes | ORM model grounding | — |
| `services/restaurant-svc/app/models/restaurant.py` | yes | yes | no | yes | ORM model grounding | — |
| `services/restaurant-svc/app/schemas/restaurant.py` | yes | yes | no | yes | Schema reference | — |
| `services/restaurant-svc/app/services/search.py` | yes | yes | no | yes | Fallback context | — |
| `services/restaurant-svc/app/db/migrations/versions/0001_create_restaurant_tables.py` | yes | yes | no | yes | Migration grounding | — |
| `services/restaurant-svc/app/db/migrations/versions/0002_money_to_numeric.py` | yes | yes | no | yes | Migration grounding | — |
| `services/restaurant-svc/app/db/migrations/versions/0003_pain_point_pricing_radius.py` | yes | yes | no | yes | Migration grounding | — |
| `services/restaurant-svc/app/db/migrations/versions/0004_add_deleted_at.py` | yes | yes | **yes** | yes | New migration fixing schema drift | IP.PR.02.001 |
| `services/restaurant-svc/app/main.py` | yes | yes | no | yes | Entry point reference | — |
| `services/restaurant-svc/pyproject.toml` | yes | yes | no | yes | Manifest reference | — |

---

## User service files

| File Path | Exists | Read End-to-End | Changed | In Closure Zip | Reason | Scope IDs |
|---|---|---|---|---|---|---|
| `services/user-svc/app/api/v1/auth.py` | yes | yes | no | yes | Auth endpoint reference | — |
| `services/user-svc/app/api/v1/users.py` | yes | yes | no | yes | Existing /users/me reference | — |
| `services/user-svc/app/core/security.py` | yes | yes | **yes** | yes | Replaced passlib with bcrypt directly | IP.PR.02.003 |
| `services/user-svc/app/core/dependencies.py` | yes | yes | no | yes | Auth dependency reference | — |
| `services/user-svc/app/repositories/user.py` | yes | yes | no | yes | Repository reference | — |
| `services/user-svc/app/schemas/user.py` | yes | yes | no | yes | Schema reference | — |
| `services/user-svc/app/models/user.py` | yes | yes | no | yes | Model reference | — |
| `services/user-svc/app/main.py` | yes | yes | **yes** | yes | Added /api/v1/me endpoint | IP.PR.02.002 |
| `services/user-svc/pyproject.toml` | yes | yes | no | yes | Manifest reference | — |

---

## Frontend web app files

| File Path | Exists | Read End-to-End | Changed | In Closure Zip | Reason | Scope IDs |
|---|---|---|---|---|---|---|
| `apps/web/package.json` | yes | yes | no | yes | Manifest reference | — |
| `apps/web/src/lib/api.ts` | yes | yes | no | yes | API client reference | — |
| `apps/web/src/store/auth.ts` | yes | yes | no | yes | Auth store reference | — |
| `apps/web/src/components/layout/Navbar.tsx` | yes | yes | **yes** | yes | Added dark mode toggle + hooks | IP.PR.02.013 |
| `apps/web/src/components/restaurant/RestaurantCard.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/components/home/FeaturedRestaurants.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/components/providers.tsx` | yes | yes | **yes** | yes | Added AuthBootstrap wrapper | IP.PR.02.003 |
| `apps/web/src/app/page.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/app/restaurants/page.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/app/restaurants/[id]/page.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/app/restaurants/[id]/error.tsx` | yes | yes | **yes** | yes | New error boundary component | IP.PR.02.007 |
| `apps/web/src/app/(auth)/login/page.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/src/app/(auth)/signup/page.tsx` | yes | yes | no | yes | Unchanged reference | — |
| `apps/web/next.config.mjs` | yes | yes | no | yes | Proxy config reference | — |

---

## New files created in SPR-02

| File Path | Exists | Included in Zip | Reason | Scope IDs |
|---|---|---|---|---|
| `apps/web/src/components/AuthBootstrap.tsx` | yes | yes | Auth rehydration on bootstrap | IP.PR.02.003 |
| `apps/web/src/app/restaurants/[id]/error.tsx` | yes | yes | Error boundary for restaurant detail | IP.PR.02.007 |
| `services/restaurant-svc/app/db/migrations/versions/0004_add_deleted_at.py` | yes | yes | Fix schema drift | IP.PR.02.001 |

---

## Summary

- **Total required files read end-to-end:** 32 source + 6 plan/evidence
- **Files changed in this session:** 5
- **New files created:** 3
- **Files missing from required list:** 0
