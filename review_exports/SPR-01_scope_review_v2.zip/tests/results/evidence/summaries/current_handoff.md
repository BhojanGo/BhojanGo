# SPR-01 Handoff

**Current Sprint:** SPR-01 — Broken Shell Stabilization  
**Date:** 2026-06-15  
**Branch:** rr_testing  

## Completed Scope IDs

| Scope ID | Status | Notes |
|----------|--------|-------|
| IP.PR.01.001 | PASS | Service boot matrix created |
| IP.PR.01.002 | PASS | bcrypt pinned (<5.0.0) in user-svc, passlib removed |
| IP.PR.01.003 | PASS | Batch-engine migration verified correct (no fix needed) |
| IP.PR.01.004 | PASS | Seed data verified: 96 restaurants, 521 categories, 1669 items |
| IP.PR.01.005 | PASS | Health check matrix created for all 8 services |
| IP.PR.01.006 | PASS | BLOCKERS.md created with 4 documented blockers |
| IP.PR.01.007 | PASS | OpenSearch added to docker-compose.yml (unvalidated — Docker missing) |
| IP.PR.01.008 | PARTIAL | HTTP route audit complete; browser/screenshot audit not performed |
| IP.PR.01.009 | PASS | start-all.sh created, made executable, tested with graceful Docker-missing fallback |
| IP.PR.01.010 | PARTIAL | Symptom documented (menu 500); root cause NOT confirmed (no stack trace captured) |

## Changed Files

- `scripts/start-all.sh` (new — corrected: Docker-missing graceful fallback, apps/web detection, logs dir creation, clear summary)
- `docker-compose.yml` (modified — added optional opensearch service)
- `services/user-svc/pyproject.toml` (modified — bcrypt pin)
- `BLOCKERS.md` (new)
- `tests/results/backend/service-startup/service-boot-matrix.md`
- `tests/results/backend/api/health-check-matrix.md`
- `tests/results/backend/migrations/seed-verification.md`
- `tests/results/backend/api/menu-endpoint-root-cause.md`
- `tests/results/evidence/manifests/SPR-01-evidence.md`
- `tests/results/frontend/customer/page-audit.md`
- `tests/results/evidence/logs/start-script-run.log`
- `tests/results/evidence/logs/docker-availability.log`
- `tests/results/evidence/logs/health-check-curl.log`
- `tests/results/evidence/logs/seed-count.log`
- `tests/results/evidence/logs/menu-endpoint-curl.log`

## Evidence Files

- `tests/results/backend/service-startup/service-boot-matrix.md`
- `tests/results/backend/api/health-check-matrix.md`
- `tests/results/backend/migrations/seed-verification.md`
- `tests/results/backend/api/menu-endpoint-root-cause.md`
- `tests/results/evidence/manifests/SPR-01-evidence.md`
- `tests/results/frontend/customer/page-audit.md`
- `tests/results/evidence/logs/start-script-run.log`
- `tests/results/evidence/logs/docker-availability.log`
- `tests/results/evidence/logs/health-check-curl.log`
- `tests/results/evidence/logs/seed-count.log`
- `tests/results/evidence/logs/menu-endpoint-curl.log`
- `BLOCKERS.md`

## Open Blockers

1. **BLOCKER-001 (HIGH — documented only, not MVP-blocking):** Docker not available — opensearch, pgbouncer, localstack, kong cannot start. Per local-first policy, these are optional before PR.08.
2. **BLOCKER-002 (LOW):** delivery-svc missing DATABASE_URL (may be intentional — uses DynamoDB)
3. **BLOCKER-003 (LOW):** reviews table empty (0 records seeded)
4. **BLOCKER-004 (LOW):** web has no `/health` endpoint
5. **BLOCKER-005 (MEDIUM — SPR-02):** `GET /api/v1/restaurants/{id}/menu` returns 500. Root cause unknown; needs stack trace capture in SPR-02.

## Next Recommended Action

1. **SPR-02 priority:** Fix menu endpoint 500 — enable debug logging on restaurant-svc, capture stack trace, implement DB fallback if OpenSearch is unavailable
2. Seed reviews data or add to comprehensive seed script
3. Add `/api/health/route.ts` to web app for monitoring
4. Continue following local-first MVP policy (no paid/cloud deps before PR.08)

## Local-First MVP Policy

- **No paid/cloud/external production services before PR.08 completion.**
- Use local/free/open-source/mock/fake adapters for all external dependencies.
- Paid/production integrations (real payment gateways, SMS providers, cloud AI) are **PR.09+ only** unless explicitly approved.
- **Mac M1 local development must remain lightweight.** Docker and external containers are optional, not blockers.
- OpenSearch is present in `docker-compose.yml` for optional local use, but the app must degrade gracefully with PostgreSQL DB fallback when OpenSearch is unavailable.
- If a feature requires an external service, implement a local/mock adapter first.
- Do not block MVP progress waiting for production-grade infrastructure.

## Files Future Sessions Should Read

- `BLOCKERS.md` — current blockers with reproduction steps
- `tests/results/backend/api/menu-endpoint-root-cause.md` — menu 500 analysis (deferred to SPR-02)
- `scripts/start-all.sh` — corrected startup script
- `docker-compose.yml` — optional opensearch service
- `tests/results/evidence/summaries/current_handoff.md` — this file

## Files Future Sessions Should Not Re-read

- `implementation_plan/SP20-Master-Implementation-Sprint-Plan.md` — already absorbed
- `implementation_plan/IP.PR.01 - Broken Shell.md` — scope executed
- `tests/results/backend/migrations/seed-verification.md` — stable unless re-seeded
- `tests/results/frontend/customer/page-audit.md` — HTTP-only snapshot; re-audit in SPR-02 with browser
