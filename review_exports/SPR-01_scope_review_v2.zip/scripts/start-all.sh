#!/bin/bash
set -e

# ── Colour codes ───────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Colour

# ── Project root ────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# ── Log helpers ────────────────────────────────────────────
log_info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
log_ok()    { echo -e "${GREEN}[ OK ]${NC}  $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*"; }

# ── PIDs file ──────────────────────────────────────────────
PIDS_FILE="$SCRIPT_DIR/.service_pids"

# ── Service list ───────────────────────────────────────────
PYTHON_SVCS=(
  "user-svc:8001"
  "restaurant-svc:8002"
  "order-svc:8003"
  "delivery-svc:8004"
  "payment-svc:8005"
  "notification-svc:8006"
)
BATCH_ENGINE="batch-engine:8007"
WEB_SVC="web:3000"

# ── Docker detection ───────────────────────────────────────
DOCKER_CMD=""
if command -v docker-compose &>/dev/null; then
  DOCKER_CMD="docker-compose"
elif command -v docker &>/dev/null && docker compose version &>/dev/null 2>&1; then
  DOCKER_CMD="docker compose"
fi

# ── Check port availability ────────────────────────────────
check_port() {
  local port=$1
  if lsof -i ":$port" >/dev/null 2>&1; then
    return 1  # port in use
  fi
  return 0   # port free
}

# ── Stop all ───────────────────────────────────────────────
stop_all() {
  log_info "Stopping all services..."

  # Kill backend PIDs
  if [[ -f "$PIDS_FILE" ]]; then
    while IFS=: read -r name pid; do
      if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        log_info "Stopping $name (PID $pid)"
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
      fi
    done < "$PIDS_FILE"
  fi

  # Stop docker-compose services
  if [[ -n "$DOCKER_CMD" ]]; then
    log_info "Stopping docker-compose services..."
    $DOCKER_CMD down 2>/dev/null || true
  fi

  # Clean up PID file
  rm -f "$PIDS_FILE"

  log_ok "All services stopped"
  exit 0
}

# ── Handle stop command ────────────────────────────────────
if [[ "${1:-}" == "stop" || "${1:-}" == "stop-all" ]]; then
  stop_all
fi

# ── Trap for clean shutdown ────────────────────────────────
trap 'stop_all' INT TERM

# ══════════════════════════════════════════════════════════
# START
# ══════════════════════════════════════════════════════════

log_info "Starting BhojanGo services..."

# ── Ensure logs dir exists ─────────────────────────────────
mkdir -p "$PROJECT_ROOT/logs"

# ── Trackers ───────────────────────────────────────────────
declare -a STARTED=()
declare -a SKIPPED=()
declare -a FAILED=()

# ── 1. Docker Compose services ─────────────────────────────
if [[ -z "$DOCKER_CMD" ]]; then
  log_warn "Docker not available — skipping docker-compose services (postgres, redis, opensearch, kong, localstack, pgbouncer)"
  SKIPPED+=("postgres:docker-missing")
  SKIPPED+=("redis:docker-missing")
  SKIPPED+=("opensearch:docker-missing")
else
  log_info "Docker detected ($DOCKER_CMD) — starting compose services..."
  if $DOCKER_CMD up --detach 2>/dev/null; then
    log_ok "docker-compose services started"
    STARTED+=("postgres")
    STARTED+=("redis")
    STARTED+=("opensearch")
  else
    log_warn "docker-compose up failed — skipping docker services"
    SKIPPED+=("postgres:docker-start-failed")
    SKIPPED+=("redis:docker-start-failed")
    SKIPPED+=("opensearch:docker-start-failed")
  fi
fi

# ── 2. Wait for Postgres ───────────────────────────────────
log_info "Waiting for Postgres..."
max_wait=60
elapsed=0
postgres_ready=false

# Prefer docker check if docker is available and postgres container exists
if [[ -n "$DOCKER_CMD" ]] && $DOCKER_CMD ps -q postgres &>/dev/null; then
  while true; do
    if docker exec "$($DOCKER_CMD ps -q postgres)" pg_isready -U bhojango >/dev/null 2>&1; then
      postgres_ready=true
      break
    fi
    sleep 2
    elapsed=$((elapsed + 2))
    if (( elapsed >= max_wait )); then
      log_warn "Postgres container did not become healthy within ${max_wait}s"
      break
    fi
  done
fi

# Fallback: check native postgres
if [[ "$postgres_ready" != "true" ]]; then
  if command -v pg_isready &>/dev/null && pg_isready -h localhost -p 5432 -U bhojango >/dev/null 2>&1; then
    postgres_ready=true
  elif command -v psql &>/dev/null && psql -h localhost -p 5432 -U bhojango -d bhojango -c "SELECT 1" >/dev/null 2>&1; then
    postgres_ready=true
  fi
fi

if [[ "$postgres_ready" == "true" ]]; then
  log_ok "Postgres is ready"
else
  log_warn "Postgres not confirmed ready — continuing anyway (services may retry connections)"
fi

# ── 3. Start Python backend services ───────────────────────
for entry in "${PYTHON_SVCS[@]}"; do
  svc_name="${entry%%:*}"
  svc_port="${entry#*:}"
  svc_dir="$PROJECT_ROOT/services/$svc_name"

  if ! check_port "$svc_port"; then
    log_warn "$svc_name port $svc_port already in use — skipping"
    SKIPPED+=("$svc_name:port-in-use")
    continue
  fi

  if [[ ! -d "$svc_dir/.venv" ]]; then
    log_warn "$svc_name has no .venv — skipping"
    SKIPPED+=("$svc_name:no-venv")
    continue
  fi

  log_info "Starting $svc_name on port $svc_port..."
  cd "$svc_dir"
  if poetry run uvicorn app.main:app --port "$svc_port" --reload \
       >> "$PROJECT_ROOT/logs/${svc_name}.log" 2>&1 &
  then
    svc_pid=$!
    echo "$svc_name:$svc_pid" >> "$PIDS_FILE"
    cd "$PROJECT_ROOT"
    log_ok "$svc_name started (PID $svc_pid)"
    STARTED+=("$svc_name")
  else
    log_error "$svc_name failed to start"
    FAILED+=("$svc_name:start-failed")
    cd "$PROJECT_ROOT"
  fi
done

# ── 4. Start batch-engine ──────────────────────────────────
batch_dir="$PROJECT_ROOT/services/batch-engine"
if ! check_port 8007; then
  log_warn "batch-engine port 8007 already in use — skipping"
  SKIPPED+=("batch-engine:port-in-use")
elif [[ ! -d "$batch_dir/node_modules" ]]; then
  log_warn "batch-engine has no node_modules — skipping"
  SKIPPED+=("batch-engine:no-node_modules")
else
  log_info "Starting batch-engine on port 8007..."
  cd "$batch_dir"
  if DATABASE_URL="${DATABASE_URL:-postgresql://bhojango:bhojango_dev@localhost:5432/bhojango}" \
     npm run dev >> "$PROJECT_ROOT/logs/batch-engine.log" 2>&1 &
  then
    svc_pid=$!
    echo "batch-engine:$svc_pid" >> "$PIDS_FILE"
    cd "$PROJECT_ROOT"
    log_ok "batch-engine started (PID $svc_pid)"
    STARTED+=("batch-engine")
  else
    log_error "batch-engine failed to start"
    FAILED+=("batch-engine:start-failed")
    cd "$PROJECT_ROOT"
  fi
fi

# ── 5. Start web (Next.js) ─────────────────────────────────
# Detect correct path: apps/web vs services/web
if [[ -f "$PROJECT_ROOT/apps/web/package.json" ]]; then
  web_dir="$PROJECT_ROOT/apps/web"
elif [[ -f "$PROJECT_ROOT/services/web/package.json" ]]; then
  web_dir="$PROJECT_ROOT/services/web"
else
  web_dir=""
fi

if [[ "${SKIP_WEB:-}" == "1" ]]; then
  log_info "SKIP_WEB=1 — skipping web"
  SKIPPED+=("web:SKIP_WEB")
elif [[ -z "$web_dir" ]]; then
  log_warn "web package.json not found in apps/web or services/web — skipping"
  SKIPPED+=("web:missing-package.json")
elif ! check_port 3000; then
  log_warn "web port 3000 already in use — skipping"
  SKIPPED+=("web:port-in-use")
else
  log_info "Starting web on port 3000..."
  cd "$web_dir"
  if pnpm --filter web dev >> "$PROJECT_ROOT/logs/web.log" 2>&1 &
  then
    svc_pid=$!
    echo "web:$svc_pid" >> "$PIDS_FILE"
    cd "$PROJECT_ROOT"
    log_ok "web started (PID $svc_pid)"
    STARTED+=("web")
  else
    log_error "web failed to start"
    FAILED+=("web:start-failed")
    cd "$PROJECT_ROOT"
  fi
fi

# ── 6. Summary ─────────────────────────────────────────────
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
log_info "Startup summary"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

for s in "${STARTED[@]}"; do
  log_ok "STARTED  — $s"
done
for s in "${SKIPPED[@]}"; do
  log_warn "SKIPPED  — $s"
done
for s in "${FAILED[@]}"; do
  log_error "FAILED   — $s"
done

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
log_info "Total: ${#STARTED[@]} started, ${#SKIPPED[@]} skipped, ${#FAILED[@]} failed"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

if [[ ${#FAILED[@]} -gt 0 ]]; then
  log_warn "Some services failed to start. Check logs/ directory."
  exit_code=1
elif [[ ${#STARTED[@]} -eq 0 ]]; then
  log_warn "No services were started."
  exit_code=1
else
  log_ok "Startup complete."
  exit_code=0
fi

echo "PIDs saved to: $PIDS_FILE"
echo "Logs: $PROJECT_ROOT/logs/"
echo "To stop all:  ./scripts/start-all.sh stop"
echo ""
exit $exit_code
