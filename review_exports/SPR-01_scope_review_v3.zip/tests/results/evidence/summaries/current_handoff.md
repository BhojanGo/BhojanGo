# SPR-01 Handoff — Corrected v3 (Source-Grounded)

**Current Sprint:** SPR-01 — Broken Shell Stabilization
**Date:** 2026-06-15
**Branch:** rr_testing
**Git HEAD:** 2a733dc — "Implementaion Planned"
**Honest Assessment:** SPR-01 is PARTIALLY COMPLETE with documented gaps.

---

## Local-First MVP Policy

- **No paid/cloud/external production services before PR.08 completion.**
- Use local/free/open-source/mock/fake adapters for all external dependencies.
- Paid/production integrations (real payment gateways, SMS providers, cloud AI) are **PR.09+ only** unless explicitly approved.
- **Mac M1 local development must remain lightweight.** Docker and external containers are optional, not blockers.
- OpenSearch is present in `docker-compose.yml` for optional local use, but the app must degrade gracefully with PostgreSQL DB fallback when OpenSearch is unavailable.
- If a feature requires an external service, implement a local/mock adapter first.
- Do not block MVP progress waiting for production-grade infrastructure.

---

## Exact Remaining Blockers

### Hard Blockers (SPR-01 cannot claim full PASS)
1. **Menu endpoint 500 (`IP.PR.01.010`)**
   - Root cause: `column menu_items.deleted_at does not exist`
   - The ORM model queries `deleted_at` but the DB migration/seed never created it.
   - This blocks the core food-ordering loop: browse → menu → cart → checkout.
   - **Next action:** Add `deleted_at` column to `menu_items` table migration, OR remove `deleted_at` from the ORM model query.

### Soft Blockers (documented, non-MVP-blocking)
2. **Docker unavailable (`BLOCKER-001`)**
   - opensearch, pgbouncer, localstack, kong cannot start.
   - These are optional per local-first policy until PR.08.

3. **reviews table empty (`BLOCKER-003`)**
   - 0 review records. Not critical for PR.01.

4. **web has no `/health` endpoint (`BLOCKER-004`)**
   - Low severity; frontend routes all return HTTP 200.

5. **bcrypt pinning incomplete (`IP.PR.01.002`)**
   - Only `user-svc` pins `bcrypt`.
   - Other Python services do not reference bcrypt/passlib in their manifests.
   - `seed_users.py` still imports `passlib`.
   - No runtime failures observed; services install and start without error.

---

## Files Future SPR-02 Session Must Read

### Required (new/changed since SPR-01)
- `BLOCKERS.md` — current blockers with reproduction steps
- `tests/results/evidence/manifests/SPR-01-evidence.md` — this closure
- `tests/results/evidence/summaries/current_handoff.md` — this file

### Required for SPR-02 scope (menu fix)
- `services/restaurant-svc/app/services/search.py` — OpenSearch index logic, menu query
- `services/restaurant-svc/app/models/menu.py` — ORM model for menu_items (check for `deleted_at`)
- `services/restaurant-svc/app/db/migrations/versions/` — migration files for menu schema
- `services/restaurant-svc/app/api/v1/restaurants.py` — restaurant/menu route handler

### Required for SPR-02 scope (auth persistence)
- `services/user-svc/app/api/v1/auth.py` — auth endpoints
- `services/user-svc/app/api/v1/users.py` — user endpoints, check for `/me`
- `apps/web/src/store/auth.ts` — frontend auth store
- `apps/web/src/lib/api.ts` — frontend API client

### Required for SPR-02 scope (frontend features)
- `apps/web/src/components/restaurant/RestaurantCard.tsx` — restaurant listing component
- `apps/web/src/components/home/FeaturedRestaurants.tsx` — homepage featured list
- `apps/web/src/components/layout/Navbar.tsx` — navigation, auth state display
- `apps/web/messages/en-US.json`, `en-IN.json`, `hi-IN.json` — i18n strings

---

## Files Future Sessions Do NOT Need to Re-read (Unless Validating SPR-01)

These files were read end-to-end and are UNCHANGED in this branch. They can be treated as stable reference:

### Infrastructure / Config (unchanged)
- `docker-compose.yml`
- `package.json` (root)
- `pnpm-workspace.yaml`

### Python service manifests (unchanged)
- All 6 `services/*/pyproject.toml` files

### Batch engine (unchanged)
- `services/batch-engine/src/db/migrations/001_create_batch_tables.sql`
- `services/batch-engine/package.json`
- `services/batch-engine/src/main.ts`

### Seed scripts (unchanged)
- `scripts/seed/run_all.sh`
- `scripts/seed/comprehensive_seed.py`
- `scripts/seed/seed_restaurants.py`
- `scripts/seed/seed_users.py`
- `scripts/seed/seed_orders.py`

### Backend main.py files (unchanged)
- All 6 `services/*/app/main.py` files

### Frontend route files (unchanged)
- All `apps/web/src/app/**/page.tsx` files listed in SPR-01
- `apps/web/package.json`

---

## Changed Files in This Session

| File | Change | Scope ID |
|---|---|---|
| `scripts/start-all.sh` | Modified — Docker-missing graceful fallback, summary output | IP.PR.01.009 |
| `BLOCKERS.md` | Created — blocker documentation | IP.PR.01.006 |
| `tests/results/evidence/manifests/SPR-01-file-read-ledger.md` | Created | — |
| `tests/results/evidence/manifests/SPR-01-evidence.md` | Created (replaces v2) | — |
| `tests/results/evidence/summaries/current_handoff.md` | Created (replaces v2) | — |
| `tests/results/evidence/logs/*` | Created — 7 raw validation logs | — |

---

## Next Recommended Action for SPR-02

1. **Fix menu endpoint 500** — highest priority hard blocker.
   - Read `services/restaurant-svc/app/models/menu.py` to check ORM `deleted_at` field.
   - Read migration files to check if `deleted_at` was added in a later migration.
   - Either: (a) run pending alembic migrations, or (b) add `deleted_at` column manually, or (c) remove `deleted_at` from the query if not needed.
   - Verify fix with `curl http://localhost:8002/api/v1/restaurants/{id}/menu`

2. **Add `/api/v1/me` endpoint** if missing — needed for auth persistence.

3. **Seed reviews data** if needed for PR.02 demo.

4. **Frontend browser audit** — capture screenshots of all critical pages.
